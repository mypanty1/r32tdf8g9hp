import {Chart, registerables} from '../dist/chart.esm.js';

Chart.register(...registerables);

export default Chart;
